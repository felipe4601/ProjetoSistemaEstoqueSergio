package br.com.insustriasergio.Industria.Sergio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IndustriaSergioApplicationTests {

	@Test
	void contextLoads() {
	}

}
