package br.com.insustriasergio.Industria.Sergio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IndustriaSergioApplication {

	public static void main(String[] args) {
		SpringApplication.run(IndustriaSergioApplication.class, args);
	}

}
